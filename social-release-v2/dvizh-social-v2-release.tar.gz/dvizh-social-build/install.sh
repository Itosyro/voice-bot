#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="2026.09.04-social.2"
PAYLOAD_DIR="${DVIZH_SOCIAL_PAYLOAD_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
SOURCE_DIR="$PAYLOAD_DIR/social-content-v2"
DATA_DIR="/var/lib/dvizh"
PACKAGE_DIR="/opt/dvizh-telegram/telegram_bot"
MODULE_ROOT="/opt/dvizh-social"
MODULE_DIR="$MODULE_ROOT/dvizh_social"
SERVICE_FILE="/etc/systemd/system/dvizh-social.service"
STATUS_FILE="$DATA_DIR/social-status.json"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="$DATA_DIR/backups/social-$STAMP"
TMP_DIR="$(mktemp -d /tmp/dvizh-social.XXXXXX)"
LOCK_FILE="/run/lock/dvizh-social.lock"
SUCCESS=0
WRITERS=(dvizh-social.service dvizh-jump.service dvizh-training.service dvizh-web-editor.service dvizh-web-week.service dvizh-bridge.service dvizh-telegram.service)
RESTORE_UNITS=(dvizh-telegram.service dvizh-bridge.service dvizh-web-week.service dvizh-web-editor.service dvizh-training.service dvizh-jump.service)

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  exec sudo -n env DVIZH_SOCIAL_PAYLOAD_DIR="$PAYLOAD_DIR" bash "$0" "$@"
fi

exec 9>"$LOCK_FILE"
if ! flock -n 9; then
  echo "Другая установка модуля «Соцсети» уже выполняется." >&2
  exit 1
fi

APP_ROOT=""
if [[ -f /opt/dvizh/static/index.html ]]; then APP_ROOT="/opt/dvizh/static"
elif [[ -f /opt/dvizh/index.html ]]; then APP_ROOT="/opt/dvizh"
else echo "Не найден веб-интерфейс ДВИЖа." >&2; exit 1
fi

cleanup() { rm -rf "$TMP_DIR"; }
start_existing_services() {
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl reset-failed "${RESTORE_UNITS[@]}" >/dev/null 2>&1 || true
  systemctl start "${RESTORE_UNITS[@]}" >/dev/null 2>&1 || true
}
rollback() {
  local code=$?
  if [[ "$SUCCESS" -eq 1 ]]; then cleanup; return 0; fi
  echo "Ошибка. Возвращаю ДВИЖ и контент-данные к предыдущему состоянию..." >&2
  for unit in "${WRITERS[@]}"; do systemctl stop "$unit" >/dev/null 2>&1 || true; done

  if [[ -f "$BACKUP_DIR/telegram.db" ]]; then
    rm -f "$DATA_DIR/telegram.db-wal" "$DATA_DIR/telegram.db-shm"
    install -m 0640 -o dvizh -g dvizh "$BACKUP_DIR/telegram.db" "$DATA_DIR/telegram.db"
  fi
  if [[ -d "$BACKUP_DIR/static" ]]; then
    for name in index.html app.js stylet.css sw.js; do
      [[ -f "$BACKUP_DIR/static/$name" ]] && cp -a "$BACKUP_DIR/static/$name" "$APP_ROOT/$name"
    done
  fi
  if [[ -d "$BACKUP_DIR/runtime" ]]; then
    for name in main.py keyboards.py weekly_store.py weekly_router.py social_store.py social_router.py; do
      if [[ -f "$BACKUP_DIR/runtime/$name" ]]; then
        cp -a "$BACKUP_DIR/runtime/$name" "$PACKAGE_DIR/$name"
      elif [[ -f "$BACKUP_DIR/runtime/.missing-$name" ]]; then
        rm -f "$PACKAGE_DIR/$name"
      fi
    done
  fi
  if [[ -d "$BACKUP_DIR/module" ]]; then
    rm -rf "$MODULE_ROOT"
    cp -a "$BACKUP_DIR/module" "$MODULE_ROOT"
  elif [[ -f "$BACKUP_DIR/.module-missing" ]]; then
    rm -rf "$MODULE_ROOT"
  fi
  if [[ -f "$BACKUP_DIR/dvizh-social.service" ]]; then
    cp -a "$BACKUP_DIR/dvizh-social.service" "$SERVICE_FILE"
  else
    rm -f "$SERVICE_FILE"
  fi
  systemctl daemon-reload >/dev/null 2>&1 || true
  start_existing_services
  if [[ -f "$BACKUP_DIR/dvizh-social.service" ]]; then
    systemctl enable --now dvizh-social.service >/dev/null 2>&1 || true
  fi
  cleanup
  exit "$code"
}
trap rollback ERR INT TERM
trap cleanup EXIT

required_units=(dvizh.service dvizh-auth.service dvizh-telegram.service dvizh-bridge.service dvizh-web-week.service dvizh-web-editor.service dvizh-training.service dvizh-jump.service)
for unit in "${required_units[@]}"; do
  systemctl is-active --quiet "$unit" || { echo "$unit не активен" >&2; exit 1; }
done
for required in main.py keyboards.py weekly_store.py weekly_router.py jump_store.py jump_router.py; do
  [[ -f "$PACKAGE_DIR/$required" ]] || { echo "Не найден $PACKAGE_DIR/$required" >&2; exit 1; }
done
for required in index.html app.js stylet.css sw.js; do
  [[ -f "$APP_ROOT/$required" ]] || { echo "Не найден $APP_ROOT/$required" >&2; exit 1; }
done
[[ -f "$DATA_DIR/telegram.db" ]] || { echo "Не найдена telegram.db" >&2; exit 1; }
[[ -f "$DATA_DIR/auth-identity.json" ]] || { echo "Не найден стабильный аккаунт ДВИЖа" >&2; exit 1; }
grep -q 'jump_store = JumpStore' "$PACKAGE_DIR/main.py"
grep -q 'menu:jump' "$PACKAGE_DIR/keyboards.py"
grep -q 'DVIZH_JUMP_LAB_V1' "$APP_ROOT/app.js"

echo "[1/8] Проверяю локальный пакет модуля «Соцсети»..."
[[ -d "$SOURCE_DIR/dvizh_social" ]] || { echo "Не найден пакет $SOURCE_DIR" >&2; exit 1; }
mkdir -p "$TMP_DIR/source/dvizh_social"
for file in __init__.py social_store.py social_router.py social_web_bridge.py; do
  [[ -f "$SOURCE_DIR/dvizh_social/$file" ]] || { echo "Не найден $SOURCE_DIR/dvizh_social/$file" >&2; exit 1; }
  cp -a "$SOURCE_DIR/dvizh_social/$file" "$TMP_DIR/source/dvizh_social/$file"
done
for file in patch_social_runtime.py patch_social_web.py dvizh-social.service; do
  [[ -f "$SOURCE_DIR/$file" ]] || { echo "Не найден $SOURCE_DIR/$file" >&2; exit 1; }
  cp -a "$SOURCE_DIR/$file" "$TMP_DIR/source/$file"
done
python3 -m py_compile \
  "$TMP_DIR/source/dvizh_social/social_store.py" \
  "$TMP_DIR/source/dvizh_social/social_web_bridge.py" \
  "$TMP_DIR/source/patch_social_runtime.py" \
  "$TMP_DIR/source/patch_social_web.py"
"/opt/dvizh-telegram/.venv/bin/python" -m py_compile "$TMP_DIR/source/dvizh_social/social_router.py"
python3 "$TMP_DIR/source/patch_social_runtime.py" --package "$PACKAGE_DIR" --check
python3 "$TMP_DIR/source/patch_social_web.py" --root "$APP_ROOT" --check

echo "[2/8] Останавливаю только процессы, которые пишут общие данные..."
for unit in "${WRITERS[@]}"; do systemctl stop "$unit" >/dev/null 2>&1 || true; done

echo "[3/8] Создаю согласованную резервную копию..."
install -d -m 0700 "$BACKUP_DIR/static" "$BACKUP_DIR/runtime"
python3 - "$DATA_DIR/telegram.db" "$BACKUP_DIR/telegram.db" <<'PY'
import sqlite3,sys
source,target=sys.argv[1:]
with sqlite3.connect(source) as src, sqlite3.connect(target) as dst: src.backup(dst)
with sqlite3.connect(target) as db: result=db.execute('PRAGMA integrity_check').fetchone()[0]
if result!='ok': raise SystemExit('backup integrity='+result)
print('backup integrity=ok')
PY
chmod 0600 "$BACKUP_DIR/telegram.db"
for name in index.html app.js stylet.css sw.js; do cp -a "$APP_ROOT/$name" "$BACKUP_DIR/static/$name"; done
for name in main.py keyboards.py weekly_store.py weekly_router.py social_store.py social_router.py; do
  if [[ -f "$PACKAGE_DIR/$name" ]]; then cp -a "$PACKAGE_DIR/$name" "$BACKUP_DIR/runtime/$name"; else touch "$BACKUP_DIR/runtime/.missing-$name"; fi
done
if [[ -d "$MODULE_ROOT" ]]; then cp -a "$MODULE_ROOT" "$BACKUP_DIR/module"; else touch "$BACKUP_DIR/.module-missing"; fi
[[ -f "$SERVICE_FILE" ]] && cp -a "$SERVICE_FILE" "$BACKUP_DIR/dvizh-social.service"

echo "[4/8] Добавляю конвейер, лестницу смелости и Telegram-команды..."
install -m 0644 -o root -g root "$TMP_DIR/source/dvizh_social/social_store.py" "$PACKAGE_DIR/social_store.py"
install -m 0644 -o root -g root "$TMP_DIR/source/dvizh_social/social_router.py" "$PACKAGE_DIR/social_router.py"
python3 "$TMP_DIR/source/patch_social_runtime.py" --package "$PACKAGE_DIR"
"/opt/dvizh-telegram/.venv/bin/python" -m compileall -q "$PACKAGE_DIR"

echo "[5/8] Создаю профиль соцсетей и отдельный тип контент-событий..."
PYTHONPATH=/opt/dvizh-telegram "/opt/dvizh-telegram/.venv/bin/python" - <<'PY'
import sqlite3
from telegram_bot.social_store import SocialStore
path='/var/lib/dvizh/telegram.db'
with sqlite3.connect(path) as db:
    rows=db.execute('SELECT chat_id FROM users WHERE authorized=1 ORDER BY chat_id').fetchall()
if len(rows)!=1: raise SystemExit(f'expected one authorized chat, found {len(rows)}')
chat_id=int(rows[0][0])
store=SocialStore(path)
profile=store.profile(chat_id)
print('social profile=ok')
print('weekly goal='+str(profile['weekly_goal']))
print('courage level='+str(profile['courage_level']))
PY

echo "[6/8] Добавляю отдельный экран «Соцсети» и запускаю мост..."
python3 "$TMP_DIR/source/patch_social_web.py" --root "$APP_ROOT"
python3 "$TMP_DIR/source/patch_social_web.py" --root "$APP_ROOT" --check
install -d -m 0755 -o root -g root "$MODULE_DIR"
for file in __init__.py social_store.py social_web_bridge.py; do
  install -m 0644 -o root -g root "$TMP_DIR/source/dvizh_social/$file" "$MODULE_DIR/$file"
done
printf '%s\n' "$VERSION" > "$MODULE_ROOT/VERSION"
chmod 0644 "$MODULE_ROOT/VERSION"
install -m 0644 -o root -g root "$TMP_DIR/source/dvizh-social.service" "$SERVICE_FILE"
systemctl daemon-reload
rm -f "$STATUS_FILE"

systemctl start dvizh-telegram.service
systemctl reset-failed dvizh-bridge.service dvizh-web-week.service dvizh-web-editor.service dvizh-training.service dvizh-jump.service >/dev/null 2>&1 || true
systemctl start dvizh-bridge.service dvizh-web-week.service dvizh-web-editor.service dvizh-training.service dvizh-jump.service
systemctl enable --now dvizh-social.service >/dev/null

echo "[7/8] Жду первой синхронизации и проверяю интерфейс..."
SOCIAL_OK=0
for _ in $(seq 1 60); do
  if [[ -f "$STATUS_FILE" ]] && python3 - "$STATUS_FILE" <<'PY' >/dev/null 2>&1
import json,sys
p=json.load(open(sys.argv[1],encoding='utf-8'))
raise SystemExit(0 if p.get('ok') else 1)
PY
  then SOCIAL_OK=1; break; fi
  sleep 1
done
if [[ "$SOCIAL_OK" -ne 1 ]]; then
  echo "Модуль соцсетей не вышел в состояние ok за 60 секунд." >&2
  [[ -f "$STATUS_FILE" ]] && cat "$STATUS_FILE" >&2 || true
  journalctl -u dvizh-social.service -n 40 --no-pager >&2 || true
  exit 1
fi
cat "$STATUS_FILE"
grep -q 'DVIZH_SOCIAL_HUB_V1' "$APP_ROOT/index.html"
grep -q 'DVIZH_SOCIAL_HUB_V1' "$APP_ROOT/app.js"
grep -q 'DVIZH_SOCIAL_HUB_V1' "$APP_ROOT/stylet.css"
grep -q 'dvizh-social-hub-v1' "$APP_ROOT/sw.js"
grep -q 'social_store = SocialStore' "$PACKAGE_DIR/main.py"
grep -q 'menu:social' "$PACKAGE_DIR/keyboards.py"
grep -q 'week:kind:social' "$PACKAGE_DIR/weekly_router.py"

echo "[8/8] Проверяю базы, API и все службы..."
python3 - "$DATA_DIR/telegram.db" "$DATA_DIR/dvizh.db" "$DATA_DIR/auth.db" <<'PY'
import sqlite3,sys
for path in sys.argv[1:]:
    with sqlite3.connect(path) as db: result=db.execute('PRAGMA integrity_check').fetchone()[0]
    print(path.split('/')[-1]+' integrity='+result)
    if result!='ok': raise SystemExit(1)
with sqlite3.connect(sys.argv[1]) as db:
    print('social_profiles='+str(db.execute('SELECT COUNT(*) FROM social_profiles').fetchone()[0]))
    print('social_content='+str(db.execute('SELECT COUNT(*) FROM social_content').fetchone()[0]))
PY
curl -fsS --max-time 8 http://127.0.0.1:8000/api/health >/dev/null
curl -fsS --max-time 8 http://127.0.0.1:8002/health >/dev/null
for unit in dvizh.service dvizh-auth.service dvizh-telegram.service dvizh-bridge.service dvizh-web-week.service dvizh-web-editor.service dvizh-training.service dvizh-jump.service dvizh-social.service; do
  printf '%s: ' "$unit"; systemctl is-active "$unit"
done

cat > /usr/local/sbin/dvizh-social-info <<'INFO'
#!/usr/bin/env bash
set -u
printf 'dvizh-social: '; systemctl is-active dvizh-social.service 2>/dev/null || true
[[ -f /var/lib/dvizh/social-status.json ]] && cat /var/lib/dvizh/social-status.json
INFO
chmod 0755 /usr/local/sbin/dvizh-social-info

SUCCESS=1
trap - ERR INT TERM
cleanup

echo
echo "DVIZH social content $VERSION installed."
echo "Backup: $BACKUP_DIR"
echo "Полностью закрой ДВИЖ и открой снова → Соцсети. В Telegram: /social или /idea текст."
